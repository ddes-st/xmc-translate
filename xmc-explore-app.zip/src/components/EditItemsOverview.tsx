import { Language } from "@/lib/LanguageService";
import { Item, getItem } from "@/lib/itemService";
import { Site } from "@/lib/sitesService";
import {
  Box,
  Heading,
  useColorMode,
  useColorModeValue,
  Text,
  Card,
  CardBody,
  CardHeader,
  Tag,
  TagLabel,
} from "@chakra-ui/react";
import { SetStateAction, useEffect, useState } from "react";
import Image from "next/image";

type EditItemsOverviewProps = {
  activeSite: Site | undefined;
  activeLanguage: Language | undefined;
  setchosenItem: (item: SetStateAction<Item | undefined>) => void;
};
export const EditItemsOverview = ({
  activeSite,
  activeLanguage,
  setchosenItem,
}: EditItemsOverviewProps) => {
  const [activeItem, setActiveItem] = useState<Item>();
  var activeCardColor = useColorModeValue("white", "black");

  async function loadActiveItem(chosenItem: Item | undefined) {
    if (chosenItem) {
      const loadedActiveItem = await getItem(
        chosenItem.itemId,
        chosenItem.language
      );
      setActiveItem(loadedActiveItem);
      setchosenItem(loadedActiveItem);
    }
  }

  useEffect(() => {
    async function loadItem() {
      if (activeSite?.startItem?.itemId && activeLanguage?.isoCode) {
        const loadedItem = await getItem(
          activeSite?.startItem?.itemId,
          activeLanguage?.isoCode
        );
        if (loadedItem) {
          setActiveItem(loadedItem);
        }
      } else {
        setActiveItem(undefined);
      }
    }
    loadItem();
  }, [activeSite, activeLanguage]);

  return (
    <Box p={2} borderRadius={"sm"} borderBottom={"1px"} minH={150}>
      <Heading fontWeight={"bold"}>Available Items</Heading>

      <Box mt={4} overflowX={"scroll"} whiteSpace={"nowrap"}>
        {activeItem ? (
          <>
            {activeItem.template != "Headless Site" ? (
              <Box>
                <Card
                  my={4}
                  mx={2}
                  width={"500px"}
                  cursor="pointer"
                  layerStyle="interactive.fill"
                  onClick={() => loadActiveItem(activeItem.parent)}
                >
                  <CardHeader>
                    <Heading size="sm">{activeItem?.parent?.name}</Heading>
                  </CardHeader>
                  <CardBody>
                    <Box>
                      <Text variant="subtle">
                        <b>Version: </b> {activeItem?.parent?.version}
                      </Text>
                      <Text variant="subtle">
                        <b>Language: </b>
                        {activeItem?.parent?.language}
                      </Text>
                      <Text variant="subtle">
                        <b>Template: </b>
                        {activeItem?.parent?.template}
                      </Text>
                      {activeItem?.parent?.workflow != null? (
                        <Tag
                          colorScheme={
                            activeItem?.parent?.workflow?.final
                              ? "green"
                              : "gray"
                          }
                        >
                          <TagLabel>
                            {activeItem?.parent?.workflow?.displayName}
                          </TagLabel>
                        </Tag>
                      ) : (
                        <Tag colorScheme={"gray"}>
                          <TagLabel>NO WORKFLOW</TagLabel>
                        </Tag>
                      )}

                      {activeItem?.parent?.thumbnailUrl != "" ? (
                        <Box
                          position={"absolute"}
                          right={5}
                          top={5}
                          as={"p"}
                          float={"right"}
                        >
                          <Image
                            alt={activeItem?.parent?.name ?? ""}
                            src={activeItem?.parent?.thumbnailUrl ?? ""}
                            width={100}
                            height={100}
                          />
                        </Box>
                      ) : (
                        <></>
                      )}
                    </Box>
                  </CardBody>
                </Card>
              </Box>
            ) : (
              <></>
            )}

            <Box>
              <Card
                size={"sm"}
                my={4}
                mx={2}
                width={"500px"}
                cursor="pointer"
                layerStyle="interactive.fill"
                bg={"teal"}
                color={activeCardColor}
              >
                <CardHeader>
                  <Heading size="sm">{activeItem?.name}</Heading>
                </CardHeader>
                <CardBody>
                  <Box>
                    <Text color={activeCardColor} variant="subtle">
                      <b>Version: </b> {activeItem?.version}
                    </Text>
                    <Text color={activeCardColor} variant="subtle">
                      <b>Language: </b>
                      {activeItem?.language}
                    </Text>
                    <Text color={activeCardColor} variant="subtle">
                      <b>Template: </b>
                      {activeItem?.template}
                    </Text>
                    {activeItem?.workflow != null? (
                        <Tag
                          colorScheme={
                            activeItem?.workflow?.final
                              ? "green"
                              : "gray"
                          }
                        >
                          <TagLabel>
                            {activeItem?.workflow?.displayName}
                          </TagLabel>
                        </Tag>
                      ) : (
                        <Tag colorScheme={"gray"}>
                          <TagLabel>NO WORKFLOW</TagLabel>
                        </Tag>
                      )}
                  </Box>
                  {activeItem?.thumbnailUrl != "" ? (
                    <Box
                      position={"absolute"}
                      right={5}
                      top={5}
                      as={"p"}
                      float={"right"}
                    >
                      <Image
                        alt={activeItem?.name ?? ""}
                        src={activeItem?.thumbnailUrl ?? ""}
                        width={100}
                        height={100}
                      />
                    </Box>
                  ) : (
                    <></>
                  )}
                </CardBody>
              </Card>
            </Box>
            <Box mt={4} mb={4}>
              {activeItem?.children?.map((element, key) => {
                return (
                  <Card
                    key={key}
                    mx={2}
                    display={"inline-block"}
                    width={"300px"}
                    cursor="pointer"
                    layerStyle="interactive.fill"
                    onClick={() => loadActiveItem(element)}
                  >
                    <CardHeader>
                      <Heading size="sm">{element?.name}</Heading>
                    </CardHeader>
                    <CardBody>
                      <Box>
                        <Text variant="subtle">
                          <b>Version: </b> {element?.version}
                        </Text>
                        <Text variant="subtle">
                          <b>Language:</b> {element?.language}
                        </Text>
                        <Text variant="subtle">
                          <b>Template: </b>
                          {element?.template}
                        </Text>
                        {element?.workflow != null ? (
                        <Tag
                          colorScheme={
                            element?.workflow?.final
                              ? "green"
                              : "gray"
                          }
                        >
                          <TagLabel>
                            {element ?.workflow?.displayName}
                          </TagLabel>
                        </Tag>
                      ) : (
                        <Tag colorScheme={"gray"}>
                          <TagLabel>NO WORKFLOW</TagLabel>
                        </Tag>
                      )}
                        {element?.thumbnailUrl != "" ? (
                          <Box
                            position={"absolute"}
                            right={5}
                            top={5}
                            as={"p"}
                            float={"right"}
                          >
                            <Image
                              alt={element?.name ?? ""}
                              src={element?.thumbnailUrl ?? ""}
                              width={100}
                              height={100}
                            />
                          </Box>
                        ) : (
                          <></>
                        )}
                      </Box>
                    </CardBody>
                  </Card>
                );
              })}
            </Box>
          </>
        ) : (
          <Box>
            <Card
              mx={2}
              width={"500px"}
              cursor="pointer"
              layerStyle="interactive.fill"
              bg={"teal"}
              color={activeCardColor}
            >
              <CardHeader>
                <Heading size="sm">There is no item to show</Heading>
              </CardHeader>
            </Card>
          </Box>
        )}
      </Box>
    </Box>
  );
};
