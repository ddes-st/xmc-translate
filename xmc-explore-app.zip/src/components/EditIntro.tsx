import { Language, Languages, getAllLanguages } from "@/lib/LanguageService";
import { Site, Sites, getSites } from "@/lib/sitesService";
import {
  Box,
  FormControl,
  FormHelperText,
  FormLabel,
  Grid,
  HStack,
  Heading,
  Select,
  Text,
} from "@chakra-ui/react";
import { useState, useEffect, SetStateAction } from "react";

type EditIntroProps = {
  setChosenSite: (site: SetStateAction<Site | undefined>) => void;
  setChosenLanguage: (site: SetStateAction<Language | undefined>) => void;
};
export const EditIntro = ({
  setChosenSite,
  setChosenLanguage,
}: EditIntroProps) => {
  const [sites, setSites] = useState<Sites>();
  const [languages, setLanguages] = useState<Languages>();
  useEffect(() => {
    async function doGetSites() {
      const loadedSites = await getSites();
      if (loadedSites) {
        setSites(loadedSites);
      }
    }

    async function doGetLanguages() {
      const loadedLanguages = await getAllLanguages();
      if (loadedLanguages) {
        setLanguages(loadedLanguages);
      }
    }

    doGetLanguages();
    doGetSites();
  }, []);

  const siteSelected = (event: any) => {
    const matchingSite = sites?.sites.filter(
      (element) => element.name == event.target.value
    )[0];
    setChosenSite(matchingSite);
  };

  const languageSelected = (event: any) => {
    const matchingLanguage = languages?.languages.filter(
      (element) => element.name == event.target.value
    )[0];
    setChosenLanguage(matchingLanguage);
  };

  return (
    <Box p={2} borderRadius={"sm"} borderBottom={"1px"} minH={50}>
      <Grid templateColumns="repeat(2, 1fr)" gap={2}>
        <Heading fontWeight={"bold"}>Site Switcher</Heading>
        <Box px={2} ml={"auto"} mr={"0"} width={"25%"}>
          <FormControl mb={2} display={"inline-block"}>
            <Select onChange={languageSelected}>
              <option>Language</option>
              {languages?.languages?.map((element, key) => {
                return (
                  <option key={key}>
                    {element.isoCode == "" ? element.name : element?.isoCode}
                  </option>
                );
              })}
            </Select>
          </FormControl>
          <FormControl display={"inline-block"}>
            <Select onChange={siteSelected}>
              <option>Site</option>
              {sites?.sites?.map((element, key) => {
                return <option key={key}>{element.name}</option>;
              })}
            </Select>
          </FormControl>
        </Box>
      </Grid>
    </Box>
  );
};
