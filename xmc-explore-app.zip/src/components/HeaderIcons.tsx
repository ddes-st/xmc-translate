import { HStack, IconButton, useColorMode } from "@chakra-ui/react";
import { BiMoon, BiSun } from "react-icons/bi";
import { FiBell } from "react-icons/fi";

export default function HeaderIcons() {
  const { colorMode, toggleColorMode } = useColorMode();
  return (
    <HStack spacing={{ base: "0", md: "4" }}>
      <IconButton
        onClick={toggleColorMode}
        size="lg"
        variant="ghost"
        aria-label="open menu"
        icon={colorMode === "light" ? <BiMoon /> : <BiSun />}
      />
      <IconButton
        size="lg"
        variant="ghost"
        aria-label="open menu"
        icon={<FiBell />}
      />
    </HStack>
  );
}
