import { SettingsContext } from "@/context/settingsContext";
import { Field, Item, getItem, updateItem } from "@/lib/itemService";
import {
  Box,
  Button,
  FormControl,
  FormHelperText,
  FormLabel,
  Grid,
  GridItem,
  Heading,
  Icon,
  IconButton,
  Input,
  Link,
  Menu,
  MenuButton,
  MenuItem,
  MenuList,
  Select,
  Tab,
  TabList,
  TabPanel,
  TabPanels,
  Tabs,
  Text,
  Tooltip,
  useToast,
} from "@chakra-ui/react";
import {
  mdiChevronDown,
  mdiCreation,
  mdiFormatTitle,
  mdiTag,
  mdiTextLong,
  mdiTextShort,
  mdiTranslate,
} from "@mdi/js";
import { useContext, useEffect, useState } from "react";
import { AiOutlineCheck, AiOutlineClose } from "react-icons/ai";
import { BiSave } from "react-icons/bi";
import { EditItemDetailsField } from "./EditItemDetailsField";
import { Language, Languages, getAllLanguages } from "@/lib/LanguageService";
import { translate } from "@/lib/OpenAiService";

type EditItemDetailsTranslateProps = {
  activeItem: Item | undefined;
};

export const EditItemDetailsTranslate = ({
  activeItem,
}: EditItemDetailsTranslateProps) => {
  let activeSetting = useContext(SettingsContext);
  const [item, setItem] = useState<Item | undefined>(activeItem);
  const [itemSource, setItemSource] = useState<Item | undefined>();
  const [itemTarget, setItemTarget] = useState<Item | undefined>();
  const [availableLanguages, setAvailableLanguages] = useState<Languages>();
  const [itemSourceLanguage, setItemSourceLanguage] = useState<Language>();
  const [itemTargetLanguage, setItemTargetLanguage] = useState<Language>();
  const [loading, setLoading] = useState(false);
  const toast = useToast();

  useEffect(() => {
    async function loadItem() {
      if (activeItem) {
        const loadedActiveItem = await getItem(
          activeItem.itemId,
          itemSourceLanguage?.name ?? activeItem.language
        );
        setItemSource(loadedActiveItem);

        const loadedTargetItem = await getItem(
          activeItem.itemId,
          itemTargetLanguage?.name ?? activeItem.language
        );
        setItemTarget(loadedTargetItem);
      }
    }

    async function doGetLanguages() {
      const loadedLanguages = await getAllLanguages();
      if (loadedLanguages) {
        setAvailableLanguages(loadedLanguages);
      }
    }
    async function doGetFieldsToTranslate() {}

    doGetLanguages();
    doGetFieldsToTranslate();
    loadItem();
    setItem(activeItem);
  }, [activeItem, itemSourceLanguage?.name, itemTargetLanguage?.name]);

  const languageSelected = (event: any) => {
    const matchingLanguage = availableLanguages?.languages.filter(
      (element) => element.name == event.target.value
    )[0];
    if (matchingLanguage) {
      setItemSourceLanguage(matchingLanguage);
    }
  };

  const targetLanguageSelected = (event: any) => {
    const matchingLanguage = availableLanguages?.languages.filter(
      (element) => element.name == event.target.value
    )[0];
    if (matchingLanguage) {
      setItemTargetLanguage(matchingLanguage);
    }
  };

  async function translateAllFields() {}

  function shouldbeUsedForTranslation(element: Field) {
    const templatesToTranslate = activeSetting?.translationSetting.children;
    if (!templatesToTranslate) {
      return false;
    }
    const templateBasedTranslationSettings = templatesToTranslate.filter(
      (element) => element.translateTemplate?.itemId == activeItem?.templateId
    )[0];
    if (!templateBasedTranslationSettings) {
      return false;
    }
    const isFieldIn = templateBasedTranslationSettings.translateFields?.filter(
      (innerElement) => innerElement.name == element.name
    );

    if (isFieldIn?.length == 0) {
      return false;
    }

    return true;
  }

  async function onFieldActionClicked(
    actionName: string,
    fieldName: string,
    value: string
  ) {
    if (actionName == "Translate") {
      const sourceField = itemSource?.fields?.filter(
        (element) => element.name == fieldName
      );
      if (!sourceField) {
        return;
      }
      setLoading(true);
      const translatedContent = await translate(
        sourceField[0]?.value,
        itemSourceLanguage?.name ?? "",
        itemTargetLanguage?.name ?? ""
      );

      await updateItem(
        itemTarget?.itemId ?? "",
        itemTargetLanguage?.name ?? "",
        [[fieldName, translatedContent.replaceAll('"', "").replaceAll("'", "")]]
      );

      const changedItem = await getItem(
        itemTarget?.itemId ?? "",
        itemTargetLanguage?.name ?? ""
      );

      setItemTarget(changedItem);

      toast({
        description: "Field '" + fieldName + "' translated",
        status: "info",
      });
      setLoading(false);
    }
  }

  return item ? (
    <>
      <Tooltip label={"Auto Translate all fields"}>
        <IconButton
          icon={
            <Icon>
              <path d={mdiTranslate} />
            </Icon>
          }
          size={"sm"}
          width={"100%"}
          aria-label={"Auto Translate"}
          variant="ai"
          onClick={translateAllFields}
        />
      </Tooltip>
      <Grid templateColumns="repeat(2, 1fr)">
        <GridItem>
          <Box p={2} borderRadius={"sm"} borderBottom={"1px"} minH={350}>
            <FormControl mb={2} display={"inline-block"}>
              <Select onChange={languageSelected}>
                <option>Item Source Language</option>
                {availableLanguages?.languages?.map((element, key) => {
                  return (
                    <option key={key}>
                      {element.isoCode == "" ? element.name : element?.isoCode}
                    </option>
                  );
                })}
              </Select>
            </FormControl>
            {itemSource?.fields?.map((element, key) => {
              if (!shouldbeUsedForTranslation(element)) {
                return <></>;
              }

              return (
                <EditItemDetailsField
                  key={key}
                  field={element}
                  activeItem={itemSource}
                  readOnly={true}
                  aiActive={false}
                  translateActive={false}
                  isLoading={loading}
                />
              );
            })}
          </Box>
        </GridItem>
        <GridItem>
          <Box p={2} borderRadius={"sm"} borderBottom={"1px"} minH={350}>
            <FormControl mb={2} display={"inline-block"}>
              <Select onChange={targetLanguageSelected}>
                <option>Item Target Language</option>
                {availableLanguages?.languages?.map((element, key) => {
                  return (
                    <option key={key}>
                      {element.isoCode == "" ? element.name : element?.isoCode}
                    </option>
                  );
                })}
              </Select>
            </FormControl>
            {itemTarget?.fields?.map((element, key) => {
              if (!shouldbeUsedForTranslation(element)) {
                return <></>;
              }
              return (
                <EditItemDetailsField
                  aiActive={false}
                  translateActive={true}
                  key={key}
                  field={element}
                  activeItem={itemTarget}
                  readOnly={false}
                  triggerAction={onFieldActionClicked}
                  isLoading={loading}
                />
              );
            })}
          </Box>
        </GridItem>
      </Grid>
    </>
  ) : (
    <></>
  );
};
