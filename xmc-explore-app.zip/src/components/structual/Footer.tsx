"use client";

import { ReactNode } from "react";

import {
  Box,
  ButtonGroup,
  Container,
  IconButton,
  SimpleGrid,
  Stack,
  Text,
  useColorMode,
  useColorModeValue,
} from "@chakra-ui/react";
import Image from "next/image";
import { FaLinkedin, FaGithub, FaTwitter } from "react-icons/fa";

const Logo = (props: any) => {
  return (
    <Image
      src="/logo.png"
      width={50}
      height={50}
      alt="Team Sitecore SE"
    />
  );
};

const ListHeader = ({ children }: { children: ReactNode }) => {
  return (
    <Text fontWeight={"500"} fontSize={"lg"} mb={2}>
      {children}
    </Text>
  );
};

export default function LargeWithLogoLeft() {
  return (
    <Container
      as="footer"
      role="contentinfo"
      py={{ base: "8", md: "10" }}
      maxW={"100%"}
      bg={useColorModeValue("gray.100", "gray.900")}
      color={useColorModeValue("gray.700", "gray.200")}
      centerContent
    >
      <Stack spacing={{ base: "4", md: "5" }} width={"90%"}>
        <Stack justify="space-between" direction="row" align="center">
          <Logo color={useColorModeValue("gray.700", "white")} />
          <Text fontSize="sm" color="fg.subtle">
            &copy; {new Date().getFullYear()} @ Sitecore Team SE.
          </Text>
        </Stack>
      </Stack>
    </Container>
  );
}
