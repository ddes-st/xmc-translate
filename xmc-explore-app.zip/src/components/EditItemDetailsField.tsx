import { SettingsContext } from "@/context/settingsContext";
import { executePrompt, titleizePromp } from "@/lib/OpenAiService";
import { Field, Item, getItem, updateItem } from "@/lib/itemService";
import {
  Button,
  FormControl,
  FormLabel,
  Icon,
  IconButton,
  Input,
  Menu,
  MenuButton,
  MenuItem,
  MenuList,
  Spinner,
  Tab,
  TabList,
  TabPanel,
  TabPanels,
  Tabs,
  Text,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalFooter,
  ModalHeader,
  ModalOverlay,
  Tooltip,
  useDisclosure,
  useToast,
  Select,
  FormHelperText,
  Divider,
  Textarea,
} from "@chakra-ui/react";
import {
  mdiCreation,
  mdiFormatTitle,
  mdiMagicStaff,
  mdiTag,
  mdiText,
  mdiTextLong,
  mdiTextShort,
  mdiTranslate,
} from "@mdi/js";
import { useContext, useEffect, useState } from "react";
import { AiOutlineCheck, AiOutlineClose } from "react-icons/ai";

type EditItemDetailsFieldProps = {
  activeItem: Item | undefined;
  field: Field | undefined;
  readOnly: boolean;
  aiActive: boolean;
  translateActive: boolean;
  triggerAction?: (
    actionName: string,
    fieldName: string,
    value: string
  ) => void;
  isLoading?: boolean;
};

export const EditItemDetailsField = ({
  field,
  activeItem,
  readOnly,
  aiActive,
  translateActive,
  triggerAction,
  isLoading=false,
}: EditItemDetailsFieldProps) => {
  let activeSetting = useContext(SettingsContext);
  const [fieldValue, setFieldValue] = useState<string>(field?.value ?? "");
  const toast = useToast();
  const aiFields = ["Title", "Abstract", "Content", "Tag"];
  const { isOpen, onOpen, onClose } = useDisclosure();
  const [selecteSourceField, setSelectedSourceField] = useState<string>(
    "Please choose a field"
  );

  useEffect(() => {
    setFieldValue(field?.value ?? "");
  }, [field]);

  function onAbort() {
    setFieldValue(field?.value ?? "");
    toast({
      description: "Field '" + field?.name + "' reverted to initial value",
      status: "warning",
    });
  }

  async function onSave() {
    if (activeItem && field) {
      await updateItem(activeItem.itemId, activeItem.language, [
        [field.name, fieldValue],
      ]);

      toast({
        description: "Field '" + field.name + "' updated",
        status: "success",
      });
    }
  }

  async function onTitleizeClicked() {
    onOpen();
  }

  async function doMagic() {
    const sourceFieldValue = activeItem?.fields?.filter(
      (element) => element.name == selecteSourceField
    )[0];
    const magicResponse = await executePrompt(
      titleizePromp,
      sourceFieldValue?.value ?? ""
    );

    await updateItem(activeItem?.itemId ?? "", activeItem?.language ?? "", [
      [field?.name ?? "", magicResponse],
    ]);

    onClose();
    toast({
      description: "Magic done for '" + field?.name ?? "",
      status: "success",
    });

    setFieldValue(magicResponse);
  }

  return (
    <>
      <FormControl mx={2} my={4}>
        <FormLabel>{field?.name}</FormLabel>
        <Input
          mr={2}
          width={readOnly ? "100%" : "75%"}
          value={fieldValue}
          onChange={(e) => setFieldValue(e.target.value)}
          disabled={readOnly}
        />
        {readOnly ? (
          <></>
        ) : (
          <>
            {" "}
            <Tooltip label="Save">
              <IconButton
                colorScheme="primary"
                size={"sm"}
                mr={2}
                icon={<AiOutlineCheck />}
                aria-label="save"
                onClick={onSave}
              />
            </Tooltip>
            <Tooltip label="Abort">
              <IconButton
                colorScheme="danger"
                size={"sm"}
                mr={2}
                icon={<AiOutlineClose />}
                aria-label="abort"
                onClick={onAbort}
              />
            </Tooltip>
            {translateActive && isLoading ? (
              <Tooltip label={"Translating..."}>
                <IconButton
                  icon={<Spinner size={"md"} color="primary" />}
                  size={"sm"}
                  aria-label={"Spinner"}
                  variant={"ghost"}
                />
              </Tooltip>
            ) : translateActive ? (
              <Tooltip label={"Auto Translate '" + field?.name + "'"}>
                <IconButton
                  icon={
                    <Icon>
                      <path d={mdiTranslate} />
                    </Icon>
                  }
                  size={"sm"}
                  aria-label={"Auto Translate"}
                  variant="ai"
                  onClick={(e) =>
                    triggerAction != undefined
                      ? triggerAction(
                          "Translate",
                          field?.name ?? "",
                          fieldValue
                        )
                      : undefined
                  }
                />
              </Tooltip>
            ) : (
              <></>
            )}

            {aiActive && isLoading ? (
              <Tooltip label={"Translating..."}>
                <IconButton
                  icon={<Spinner size={"md"} color="primary" />}
                  size={"sm"}
                  aria-label={"Spinner"}
                  variant={"ghost"}
                />
              </Tooltip>
            ) : aiActive && aiFields.includes(field?.name ?? "") ? (
              <Menu>
                <Tooltip label="AI Capabilities">
                  <MenuButton
                    size={"sm"}
                    as={Button}
                    variant="ai"
                    rightIcon={
                      <Icon layerStyle="menuButtonIcon">
                        <path d={mdiCreation} />
                      </Icon>
                    }
                  >
                    AI
                  </MenuButton>
                </Tooltip>
                <MenuList>
                  {field?.name == "Title" ? (
                    <MenuItem
                      onClick={onTitleizeClicked}
                      icon={
                        <Icon>
                          <path d={mdiFormatTitle} />
                        </Icon>
                      }
                      _hover={{ background: "blackAlpha.100" }}
                    >
                      Titleize
                    </MenuItem>
                  ) : (
                    <></>
                  )}
                  {field?.name == "Abstract" ? (
                    <MenuItem
                      icon={
                        <Icon>
                          <path d={mdiText} />
                        </Icon>
                      }
                      _hover={{ background: "blackAlpha.100" }}
                    >
                      Generate Abstract
                    </MenuItem>
                  ) : (
                    <></>
                  )}
                  {field?.name == "Tag" ? (
                    <MenuItem
                      icon={
                        <Icon>
                          <path d={mdiTag} />
                        </Icon>
                      }
                      _hover={{ background: "blackAlpha.100" }}
                    >
                      Generate Tag
                    </MenuItem>
                  ) : (
                    <></>
                  )}
                  {field?.name != "Title" ? (
                    <MenuItem
                      icon={
                        <Icon>
                          <path d={mdiTextLong} />
                        </Icon>
                      }
                      _hover={{ background: "blackAlpha.100" }}
                    >
                      Make longer
                    </MenuItem>
                  ) : (
                    <></>
                  )}
                  {field?.name != "Title" ? (
                    <MenuItem
                      icon={
                        <Icon>
                          <path d={mdiTextShort} />
                        </Icon>
                      }
                      _hover={{ background: "blackAlpha.100" }}
                    >
                      Make short
                    </MenuItem>
                  ) : (
                    <></>
                  )}

                  {field?.name != "Title" && field?.name != "Tag" ? (
                    <MenuItem
                      icon={
                        <Icon>
                          <path d={mdiMagicStaff} />
                        </Icon>
                      }
                      _hover={{ background: "blackAlpha.100" }}
                    >
                      Change tone
                    </MenuItem>
                  ) : (
                    <></>
                  )}

                  <MenuItem
                    icon={
                      <Icon>
                        <path d={mdiTag} />
                      </Icon>
                    }
                    _hover={{ background: "blackAlpha.100" }}
                  >
                    Custom Promt
                  </MenuItem>

                  {/* <MenuItem _hover={{background: "blackAlpha.100"}} color="danger">Delete</MenuItem> */}
                </MenuList>
              </Menu>
            ) : (
              <></>
            )}
          </>
        )}

        {/* <FormHelperText>
    Helper text <Link>with a link at the end</Link>
  </FormHelperText> */}
      </FormControl>

      <Modal size={"md"} onClose={onClose} isOpen={isOpen}>
        <ModalOverlay />
        <ModalContent>
          <ModalHeader>Execute generative AI functionality</ModalHeader>
          <ModalCloseButton />
          <ModalBody>
            <Text fontWeight={"bold"} mb={4}>
              Please choose from an existing field or write your own source
              input
            </Text>
            <Divider mb={4} />
            <FormControl>
              <FormLabel>Source field</FormLabel>
              <Select
                onChange={(e) => setSelectedSourceField(e.target.value)}
                value={selecteSourceField}
              >
                <option>Please choose a field</option>
                <option>Abstract</option>
                <option>Content</option>
              </Select>
            </FormControl>
            <FormControl mt={2}>
              <FormLabel>Free Text</FormLabel>
              <Textarea />
            </FormControl>
          </ModalBody>
          <ModalFooter>
            <Button onClick={doMagic}>Do Magic</Button>
            <Button ml={2} colorScheme={"danger"} onClick={onClose}>
              Close
            </Button>
          </ModalFooter>
        </ModalContent>
      </Modal>
    </>
  );
};
