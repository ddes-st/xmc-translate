import { Item } from "@/lib/itemService";
import {
  Box,
  Heading,
  Tab,
  TabList,
  TabPanel,
  TabPanels,
  Tabs,
  Text,
} from "@chakra-ui/react";
import { EditItemDetailsContent } from "./EditItemDetailsContent";
import { useEffect, useState } from "react";
import { EditItemDetailsTranslate } from "./EditItemDetailsTranslate";

type EditItemDetailsProps = {
  activeItem: Item | undefined;
};

export const EditItemDetails = ({ activeItem }: EditItemDetailsProps) => {
  const [item, setItem] = useState<Item | undefined>(activeItem);

  useEffect(() => {
    setItem(activeItem);
  }, [activeItem]);

  return item ? (
    <Box p={2} borderRadius={"sm"} borderBottom={"1px"} minH={350}>
      {/* <Heading fontWeight={"bold"}>EDIT DETAILS</Heading> */}
      <Tabs size="lg">
        <TabList>
          <Tab>Content</Tab>
          <Tab>Translation</Tab>
          <Tab>Workflows</Tab>
        </TabList>

        <TabPanels>
          <TabPanel>
            <EditItemDetailsContent activeItem={item} />
          </TabPanel>
          <TabPanel>
            <EditItemDetailsTranslate activeItem={item} />
          </TabPanel>
          <TabPanel></TabPanel>
        </TabPanels>
      </Tabs>
    </Box>
  ) : (
    <></>
  );
};
