import { SettingsContext } from "@/context/settingsContext";
import { Item } from "@/lib/itemService";
import {
  Box,
  Button,
  FormControl,
  FormHelperText,
  FormLabel,
  Heading,
  Icon,
  IconButton,
  Input,
  Link,
  Menu,
  MenuButton,
  MenuItem,
  MenuList,
  Tab,
  TabList,
  TabPanel,
  TabPanels,
  Tabs,
  Text,
  Tooltip,
} from "@chakra-ui/react";
import {
  mdiChevronDown,
  mdiCreation,
  mdiFormatTitle,
  mdiTag,
  mdiTextLong,
  mdiTextShort,
} from "@mdi/js";
import { useContext, useEffect, useState } from "react";
import { AiOutlineCheck, AiOutlineClose } from "react-icons/ai";
import { BiSave } from "react-icons/bi";
import { EditItemDetailsField } from "./EditItemDetailsField";

type EditItemDetailsContentProps = {
  activeItem: Item|undefined;
};

export const EditItemDetailsContent = ({
  activeItem,
}: EditItemDetailsContentProps) => {
  let activeSetting = useContext(SettingsContext);
  const [item, setItem] = useState<Item|undefined>(activeItem);

  useEffect(() => {
    setItem(activeItem);
  }, [activeItem]);

  return item ? (
    <Box p={2} borderRadius={"sm"} borderBottom={"1px"} minH={350}>
      {item?.fields?.map((element, key) => {
        return (
          <EditItemDetailsField
            key={key}
            field={element}
            activeItem={item}
            aiActive={true}
            readOnly={false}
            translateActive={false}
          />
        );
      })}
    </Box>
  ) : (
    <></>
  );
};
