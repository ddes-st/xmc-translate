import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import {
  SITECORE_BEARER_SESSION_KEY,
  callAuthentication,
} from "./lib/authenticationService";

// This function can be marked `async` if using `await` inside
export async function middleware(request: NextRequest) {
  const response = NextResponse.next();

  /* Redirect from HOME directly to EDIT */
  const withHome = process.env.NEXT_PUBLIC_WITH_HOME == "true" ? true : false;
  if (!withHome && request.nextUrl.pathname == "/") {
    const url = request.nextUrl.clone();
    url.pathname = "/explore";
    return NextResponse.redirect(url);
  }

  /* Check if token still exists -> If not reauthenticate*/
  var existingToken = request.cookies.get(SITECORE_BEARER_SESSION_KEY);
  if (!existingToken) {
    var authresult = await callAuthentication();
    if (authresult) {
      var now = new Date();
      const expiresAt = authresult.expires_in;
      response.cookies.set(
        SITECORE_BEARER_SESSION_KEY,
        authresult.access_token,
        { expires: now.setSeconds(now.getSeconds() + expiresAt) }
      );
    }
  }

  return response;
}

// See "Matching Paths" below to learn more
export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - api (API routes)
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     */
    "/((?!api|_next/static|_next/image|favicon.ico|logo.png).*)",
  ],
};
