import LargeWithLogoLeft from "@/components/structual/Footer";
import SidebarWithHeader from "@/components/structual/SidebarNavigation";
import { Box, Center, Heading, Text, useColorMode } from "@chakra-ui/react";
import { GetStaticProps } from "next";
import Image from "next/image";

export default function Page() {
  const { colorMode } = useColorMode();

  return (
    <>
      {/*HEADER / SIDEBAR*/}
      <SidebarWithHeader>
        {/*CONTENT*/}
        <Box>
          <Center mb={4}>
            <Heading fontSize={"7xl"}>404 - Page not found</Heading>
          </Center>
          <Box mb={4}>
            <Center>
              <Text variant={"large"}>
                Looking for more content? Sorry...
              </Text>
            </Center>
          </Box>
        </Box>
        {/*FOOTER*/}
      </SidebarWithHeader>
    </>
  );
}

type Props = Record<string, never>;

export const getStaticProps: GetStaticProps<Props> = () => {
  return { props: {} };
};
