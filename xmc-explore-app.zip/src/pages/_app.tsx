import type { AppProps } from "next/app";
import sitecoreTheme from "@sitecore/blok-theme";
import { ChakraProvider } from "@chakra-ui/react";
import { SettingsProvider } from "@/context/settingsContext";

export default function App({ Component, pageProps }: AppProps) {
  return (
    <ChakraProvider
      theme={sitecoreTheme}
      toastOptions={{
        defaultOptions: {
          position: "bottom-left",
          variant: "subtle",
        },
      }}
    >
      <SettingsProvider>
        <Component {...pageProps} />
      </SettingsProvider>
    </ChakraProvider>
  );
}
