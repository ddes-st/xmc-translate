import { getUser } from "@/lib/userService";
import { NextApiRequest, NextApiResponse } from "next";
import { NextRequest } from "next/server";

export default async function getUserServer(
  req: NextApiRequest,
  res: NextApiResponse
) {
  const {
    query: { token },
  } = req;

  var result = await getUser(token as string);
  if (result) {
    return res.json(result);
  }
  return res.status(401).json({ Error: result });
}
