import {
  SITECORE_BEARER_SESSION_KEY,
} from "@/lib/authenticationService";
import { doQuery } from "@/lib/graphQLService";
import { NextApiRequest, NextApiResponse } from "next";

// specify concrete queries and only send parameters from client

export default async function executeCmGraphQuery(
  req: NextApiRequest,
  res: NextApiResponse
) {
  const token = req.cookies[SITECORE_BEARER_SESSION_KEY];
  var parsedBody = JSON.parse(req.body);
  var query = parsedBody.query as string;
  //   var variables = params.variables as string[];

  var result = await doQuery(parsedBody.query, token);
  if (result) {
    return res.json(result);
  }
  return res.status(401).json({ Error: result });
}
