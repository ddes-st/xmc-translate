import { EditIntro } from "@/components/EditIntro";
import { EditItemDetails } from "@/components/EditItemDetails";
import { EditItemsOverview } from "@/components/EditItemsOverview";
import LargeWithLogoLeft from "@/components/structual/Footer";
import SidebarWithHeader from "@/components/structual/SidebarNavigation";
import { Language } from "@/lib/LanguageService";
import { Item } from "@/lib/itemService";
import { Site } from "@/lib/sitesService";
import { Box, Center, Heading, Text } from "@chakra-ui/react";
import { useState } from "react";

export default function Page() {
  const [chosenSite, setChosenSite] = useState<Site | undefined>();
  const [chosenLanguage, setChosenLanguage] = useState<Language | undefined>();
  const [chosenItem, setChosenItem] = useState<Item|undefined>();

  return (
    <>
      {/*HEADER / SIDEBAR*/}
      <SidebarWithHeader>
        {/*CONTENT*/}
        <Box>
          <Center mb={4} mt={2}>
            <Heading fontSize={"5xl"}>Explore your Sitecore Items</Heading>
          </Center>
        </Box>
        <Box>
          <EditIntro setChosenSite={setChosenSite} setChosenLanguage={setChosenLanguage} />
        </Box>
        <Box>
          <EditItemsOverview activeSite={chosenSite} activeLanguage={chosenLanguage} setchosenItem={setChosenItem} />
        </Box>
        <Box>
          <EditItemDetails activeItem={chosenItem}/>
        </Box>
        {/*FOOTER*/}
      </SidebarWithHeader>
    </>
  );
}
