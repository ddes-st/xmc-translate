import { SettingsItem, getTranslationSettings } from "@/lib/settingsService";
import { createContext, useEffect, useState } from "react";

export interface SettingsContextType {
  translationSetting: SettingsItem;
}

type Props = {
  children?: React.ReactNode;
};

export const SettingsContext = createContext<SettingsContextType | null>(null);

export function SettingsProvider({ children }: Props): React.ReactNode {
  const [settings, setSettings] = useState<SettingsContextType | null>(null);
  useEffect(() => {
    async function loadTranslationSetting() {
      try {
        const loadedTranslationSetting = await getTranslationSettings();
        if (loadedTranslationSetting) {
          setSettings({
            ...settings,
            translationSetting: loadedTranslationSetting,
          });
        }
      } catch (error) {
        console.error("Error in getSettings in SettingsProvider:", error);
      }
    }

    if (!settings) {
      loadTranslationSetting();
    }
  }, [settings]);

  return (
    <SettingsContext.Provider value={settings}>
      {children}
    </SettingsContext.Provider>
  );
}
