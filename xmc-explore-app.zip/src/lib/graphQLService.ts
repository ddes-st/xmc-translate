import axios from "axios";
import { getToken } from "./authenticationService";

export async function doQuery(
  query: string,
  token?: string
): Promise<any> {
  const url =
    process.env.NEXT_PUBLIC_CM_SERVER_HOST! +
    process.env.NEXT_PUBLIC_CM_SERVER_GRAPH_API!;
  const usedToken = token ?? getToken();
  try {
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        Authorization: `Bearer ${usedToken}`,
      },
      body: JSON.stringify({ query: query }),
    });
    return await response.json();
  } catch (err) {
    console.log("ERROR DURING AXIOS REQUEST", err);
    return "";
  }
}
