import { Item, getItem } from "./itemService";

const guidRegex = /{([0-9A-Fa-f-]+)}/g;

export interface TranslationSetting {
  name: string;
  itemId: string;
  template: string;
  translateTemplateId: string;
  translateFieldsId: string;
  translateTemplate?: Item | undefined;
  translateFields?: Item[] | undefined;
}

export interface SettingsItem {
  name: string;
  itemId: string;
  children?: TranslationSetting[] | undefined;
}

export async function getTranslationSettings(
  activeSite?: string,
  language?: string
): Promise<SettingsItem | undefined> {
  // TODO get all sites, loop through all sites
  activeSite = "Demo Site A";

  try {
    const query = `{
    item(
      where: {
        database: "master"
        path: "sitecore/content/Demo Tenant/${activeSite}/Settings/Translation"
        language: "en"
      }
    ) {
      name
      itemId
      template {
        templateId
      }
      children {
        nodes {
          name
          itemId
          SettingsTemplate: template {
            SettingsTemplateId: templateId
          }
          TranslateFields: field(name: "Fields") {
            value
          }
          TranslateTemplate: field(name: "Template") {
            value
          }
        }
      }
    }
  }`;
    const settingsQueryResponse = await fetch("/api/executeCmGraphQuery", {
      body: JSON.stringify({ query: query }),
      method: "POST",
    });

    var mappedItemQueryResponse = await settingsQueryResponse.json();

    const settingsRoot: SettingsItem = {
      itemId: mappedItemQueryResponse?.data?.item?.itemId,
      name: mappedItemQueryResponse?.data?.item?.name,
      children: undefined,
    };

    const mappedPromises =
      mappedItemQueryResponse?.data?.item?.children?.nodes?.map(
        async (element: any) => {
          // get GUIDs from TranslateFields value and resolve items
          let match;
          const fieldItems: Item[] = [];
          while (
            (match = guidRegex.exec(element?.TranslateFields?.value)) !== null
          ) {
            const guid = match[1];
            fieldItems.push(await getItem(guid));
          }

          const child: TranslationSetting = {
            name: element.name,
            itemId: element.itemId,
            template: element?.template?.templateId,
            translateFieldsId: element?.TranslateFields.value,
            translateTemplateId: element?.TranslateTemplate.value,
            translateTemplate: await getItem(element?.TranslateTemplate.value),
            translateFields: fieldItems,
          };
          return child;
        }
      );
    settingsRoot.children = await Promise.all(mappedPromises);
    return settingsRoot;
  } catch (ex) {
    console.log(ex);
    return undefined;
  }
}
