import { doQuery } from "./graphQLService";

export interface Field {
  name: string;
  id: string;
  value: string;
}

export interface Item {
  name: string;
  version: number;
  itemId: string;
  language: string;
  children?: Item[] | undefined;
  parent?: Item | undefined;
  template: string;
  templateId: string;
  thumbnailUrl: string;
  workflow?: Workflow;
  fields?: Field[];
}

interface Workflow {
  displayName: string;
  final: boolean;
  icon: string;
  id: string;
}

const itemQuery = `
fields(ownFields: false excludeStandardFields: true) {
  nodes {
    fieldId
    name
    value
  }
}
name
itemId
version
template{name templateId}
language {name}
thumbnailUrl
workflow {
    workflowState {
      displayName
      final
      icon
      stateId
    }
  }`;

export async function updateItem(
  itemId: string,
  language: string,
  fieldUpdates: [string, string][]
): Promise<void> {
  let fieldQuery = "";
  fieldUpdates.map((element) => {
    fieldQuery += ` fields: [{ name: "${element[0]}", value: "${element[1]}" }]`;
  });
  const query = `mutation { updateItem(
      input: {
        database: "master"
        language: "${language}"
        itemId: "${itemId}"
        ${fieldQuery}
      }
    ) {
      item {
        itemId
      }
    }}`;
  const itemQueryResponse = await fetch("/api/executeCmGraphQuery", {
    body: JSON.stringify({ query: query }),
    method: "POST",
  });
}

export async function getItem(
  itemId: string,
  language?: string
): Promise<Item> {
  const query = `{item(where: {database: "master" itemId:"${itemId}", language:"${
    language ?? "en"
  }"}){
    ${itemQuery}
    parent {
        ${itemQuery}
    }
    children {
        nodes {
            ${itemQuery}
        }
      }
  }
}`;
  const itemQueryResponse = await fetch("/api/executeCmGraphQuery", {
    body: JSON.stringify({ query: query }),
    method: "POST",
  });

  var mappedItemQueryResponse = await itemQueryResponse.json();
  const parentWorkflow: Workflow = {
    displayName:
      mappedItemQueryResponse?.data?.item?.parent?.workflow?.workflowState
        ?.displayName,
    icon: mappedItemQueryResponse?.data?.item?.parent?.workflow?.workflowState
      ?.icon,
    id: mappedItemQueryResponse?.data?.item?.parent?.workflow?.workflowState
      ?.stateId,
    final:
      mappedItemQueryResponse?.data?.item?.parent?.workflow?.workflowState
        ?.final,
  };

  let parentItemFields: Field[];
  parentItemFields =
    mappedItemQueryResponse?.data?.item?.parent?.fields?.nodes?.map(
      (element: any) => {
        const itemField: Field = {
          id: element?.fieldId,
          name: element?.name,
          value: element?.value,
        };

        return itemField;
      }
    );

  const parentItem: Item = {
    thumbnailUrl: mappedItemQueryResponse?.data?.item?.parent?.thumbnailUrl
      ? process?.env?.NEXT_PUBLIC_CM_SERVER_HOST +
        mappedItemQueryResponse?.data?.item?.parent?.thumbnailUrl
      : "",
    version: mappedItemQueryResponse?.data?.item?.parent?.version,
    name: mappedItemQueryResponse?.data?.item?.parent?.name,
    children: undefined,
    itemId: mappedItemQueryResponse?.data?.item?.parent?.itemId,
    parent: undefined,
    language: mappedItemQueryResponse?.data?.item?.parent?.language?.name,
    template: mappedItemQueryResponse?.data?.item?.parent?.template?.name,
    templateId: mappedItemQueryResponse?.data?.item?.parent?.template?.templateId,
    workflow: mappedItemQueryResponse?.data?.item?.parent?.workflow
      ?.workflowState?.stateId
      ? parentWorkflow
      : undefined,
    fields: parentItemFields,
  };

  const workflow: Workflow = {
    displayName:
      mappedItemQueryResponse?.data?.item?.workflow?.workflowState?.displayName,
    icon: mappedItemQueryResponse?.data?.item?.workflow?.workflowState?.icon,
    id: mappedItemQueryResponse?.data?.item?.workflow?.workflowState?.stateId,
    final: mappedItemQueryResponse?.data?.item?.workflow?.workflowState?.final,
  };

  let itemFields: Field[];
  itemFields = mappedItemQueryResponse?.data?.item?.fields?.nodes?.map(
    (element: any) => {
      const itemField: Field = {
        id: element?.fieldId,
        name: element?.name,
        value: element?.value,
      };

      return itemField;
    }
  );

  const item: Item = {
    parent: parentItem,
    thumbnailUrl: mappedItemQueryResponse?.data?.item?.thumbnailUrl
      ? process?.env?.NEXT_PUBLIC_CM_SERVER_HOST +
        mappedItemQueryResponse?.data?.item?.thumbnailUrl
      : "",
    version: mappedItemQueryResponse?.data?.item?.version,
    itemId: mappedItemQueryResponse?.data?.item?.itemId,
    name: mappedItemQueryResponse?.data?.item?.name,
    language: mappedItemQueryResponse?.data?.item?.language?.name,
    children: undefined,
    template: mappedItemQueryResponse?.data?.item?.template?.name,
    templateId: mappedItemQueryResponse?.data?.item?.template?.templateId,
    workflow: mappedItemQueryResponse?.data?.item?.workflow?.workflowState
      ?.stateId
      ? workflow
      : undefined,
    fields: itemFields,
  };

  item.children = mappedItemQueryResponse?.data?.item?.children?.nodes?.map(
    (element: any) => {
      const childWorkflow: Workflow = {
        displayName: element?.workflow?.workflowState?.displayName,
        icon: element?.workflow?.workflowState?.icon,
        id: element?.workflow?.workflowState?.stateId,
        final: element?.workflow?.workflowState?.final,
      };

      let childItemFields: Field[];
      childItemFields = element?.fields?.nodes?.map((element: any) => {
        const itemField: Field = {
          id: element?.fieldId,
          name: element?.name,
          value: element?.value,
        };

        return itemField;
      });

      const child: Item = {
        thumbnailUrl: element?.thumbnailUrl
          ? process?.env?.NEXT_PUBLIC_CM_SERVER_HOST + element.thumbnailUrl
          : "",
        version: element.version,
        name: element.name,
        itemId: element.itemId,
        language: element.language.name,
        children: undefined,
        parent: item,
        template: element?.template?.name,
        templateId: element?.template?.templateId,
        workflow:
          element?.workflow?.workflowState?.stateId != undefined
            ? childWorkflow
            : undefined,
        fields: childItemFields,
      };

      return child;
    }
  );
  return item;
}
