import { doQuery } from "./graphQLService";
import { Item } from "./itemService";

export interface Site {
  name: string;
  startItem: Item;
}

export interface Sites {
  sites: Site[];
}

export async function getSites(): Promise<Sites> {
  const query =
    "{ sites { name startItem {itemId name version template{name templateId} language{name}} }}";
  const sitesQueryResponse = await fetch("/api/executeCmGraphQuery", {
    body: JSON.stringify({ query: query }),
    method: "POST",
  });

  var mappedSitesQueryResponse = await sitesQueryResponse.json();
  const sites: Sites = {
    sites: mappedSitesQueryResponse?.data?.sites?.map((element: any) => {
      const startItem: Item = {
        thumbnailUrl: "",
        workflow: undefined,
        version: element?.startItem?.version,
        name: element?.startItem?.name,
        itemId: element?.startItem?.itemId,
        language: element?.startItem?.language?.name,
        template: element?.startItem?.template?.name,
        templateId: element?.startItem?.template?.templateId,
      };
      const site: Site = {
        name: element.name,
        startItem: startItem,
      };
      return site;
    }),
  };
  return sites;
}
