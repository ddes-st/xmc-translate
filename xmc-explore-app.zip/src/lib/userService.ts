import axios from "axios";
import Cookies from "universal-cookie";
import { getToken } from "./authenticationService";

/* Test Functions in case we have user based login */
export async function getUserServer() {
  const token = getToken();
  if (token) {
    const userData = await axios.get("/api/getUserServer",
      { params: { token: token } }
    );
  }
}

export async function getUser(token: string) {
  try {
    const userData = await axios.get(
      "https://identity.sitecorecloud.io/api/identity/v1/user",
      {
        headers: {
          Authorization: "Bearer " + token,
        },
      }
    );
    return userData.data;
  } catch (error) {
    return error;
  }
}
