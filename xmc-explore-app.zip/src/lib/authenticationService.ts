import axios from "axios";
import Cookies from "universal-cookie";

export const SITECORE_BEARER_SESSION_KEY = "SitecoreBearer";
export const SITECORE_EXPIRES_AT_SESSION_KEY = "SitecoreExpiresAt";

export type AuthenticationResult = {
  access_token: string;
  expires_in: number;
  scope: string;
};

export function getToken() : string {
  const cookies = new Cookies({ path: "/" });
  const token = cookies.get(SITECORE_BEARER_SESSION_KEY);
  return token;
}

export function isAuthenticated() : boolean {
  const token = getToken();
  return token != undefined && token != "";
}

/* serverside */
export async function callAuthentication(): Promise<
  AuthenticationResult | undefined
> {
  const url = process.env.AUTH_AUTHORITY!;

  try {
    const result = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/JSON" },
      body: JSON.stringify({
        client_id: process.env.AUTH_CLIENT_ID!,
        client_secret: process.env.AUTH_CLIENT_SECRET!,
        audience: process.env.AUTH_AUDIENCE!,
        grant_type: process.env.AUTH_GRANT_TYPE!,
      }),
    });
    // const result = await axios.post(
    //   url,
    //   {
    //     client_id: process.env.AUTH_CLIENT_ID!,
    //     client_secret: process.env.AUTH_CLIENT_SECRET!,
    //     audience: process.env.AUTH_AUDIENCE!,
    //     grant_type: process.env.AUTH_GRANT_TYPE!,
    //   },
    //   {
    //     headers: {
    //       "Content-Type": "application/x-www-form-urlencoded",
    //     },
    //   }
    // );

    // const authenticationResult: AuthenticationResult = {
    //   access_token: result.access_token,
    //   scope: result.data.scope,
    //   expiresAt: result.data.expiresAt,
    // };

    var jsonResult = await result.json();

    const authenticationResult: AuthenticationResult = {
      access_token: jsonResult.access_token,
      scope: jsonResult.scope,
      expires_in: jsonResult.expires_in,
    };

    return authenticationResult;
  } catch (error) {
    console.error("Error in callAuthentication:", error);
    return undefined;
  }
}
