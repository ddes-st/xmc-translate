export async function translate(
  input: string,
  originLanguage: string,
  targetLanguage: string
): Promise<string> {
  const relPath = "chat/completions";
  const url = process.env.NEXT_PUBLIC_OPENAI_ENDPOINT! + relPath;
  const message = `Translate the following ${originLanguage} text to ${targetLanguage}: '${input}'`;
  const response = await fetch(url, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${process.env.NEXT_PUBLIC_OPENAI_KEY}`,
    },
    body: JSON.stringify({
      model: "gpt-3.5-turbo",
      messages: [{ role: "user", content: message }],
      temperature: 0.7,
    }),
  });
  const jsonResponse = await response.json();

  const translatedContent = jsonResponse.choices[0].message.content;
  return translatedContent;
}

export const titleizePromp =
  "Generate a proper Ttitle for the following given Text: {0}. Just output the generated title as string without any brackets or quotation marks";

export async function executePrompt(
  prompt: string,
  input: string
): Promise<string> {
  const relPath = "chat/completions";
  const url = process.env.NEXT_PUBLIC_OPENAI_ENDPOINT! + relPath;
  prompt = prompt.replace("{0}", input);
  const response = await fetch(url, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      Authorization: `Bearer ${process.env.NEXT_PUBLIC_OPENAI_KEY}`,
    },
    body: JSON.stringify({
      model: "gpt-3.5-turbo-16k-0613",
      messages: [{ role: "user", content: prompt }],
      temperature: 0.7,
    }),
  });
  const jsonResponse = await response.json();

  const translatedContent = jsonResponse.choices[0].message.content;
  return translatedContent;
}
