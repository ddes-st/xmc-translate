import { doQuery } from "./graphQLService";
import { Item } from "./itemService";

export interface Language {
  name: string;
  isoCode: string;
}

export interface Languages {
  languages: Language[];
}

export async function getAllLanguages(): Promise<Languages> {
  const query = `{
    item(
      where: {
        database: "master"
        path: "/sitecore/system/Languages"
        language: "en"
      }
    ) {
      children {
        nodes {
          name
          isoCode: field(name: "Regional Iso Code") {
            value
          }
        }
      }
    }
  }`;

  const languagesQueryResponse = await fetch("/api/executeCmGraphQuery", {
    body: JSON.stringify({ query: query }),
    method: "POST",
  });

  var mappedSitesQueryResponse = await languagesQueryResponse.json();
  const languages: Languages = {
    languages: mappedSitesQueryResponse?.data?.item?.children?.nodes?.map(
      (element: any) => {
        const languageItem: Language = {
          name: element?.name,
          isoCode:
            element?.isoCode?.value != ""
              ? element?.isoCode?.value
              : element?.name,
        };

        return languageItem;
      }
    ),
  };
  return languages;
}
