{
  title: 'Sitecore xm cloud - management',

  connection: {
    fields: [
      {
        name: 'client_id',
        optional: false,
      },
      {
        name: 'client_secret',
#        control_type: 'password',
        optional: false,
      },
       {
        name: 'base_url',
        optional: false,
      },
       {
        name: 'audience',
        optional: false, 
      },
       {
        name: 'cm_server',
        optional: false, 
      }
      
   
    ],

    authorization: {
      type: 'custom_auth', #Set to custom_auth

      acquire: lambda do |connection|
        response = post(connection['base_url'] + '/oauth/token'). 
                      payload(grant_type:'client_credentials').
                      payload(client_id:connection['client_id']).
                      payload(client_secret:connection['client_secret']).
                      payload(audience:connection['audience']).
                      request_format_www_form_urlencoded

        {
          access_token: response["access_token"],
          refresh_token: response["refresh_token"]
        }
      end,
      
        apply: lambda do |connection|
        headers("Authorization": "Bearer #{connection['access_token']}")
      end,

     detect_on: [/AUTH_NOT_AUTHENTICATED/],
     refresh_on: [/AUTH_NOT_AUTHENTICATED/]
    },

    base_uri: lambda do |connection|
      connection['cm_server']
    end

  },

  test: lambda do |connection|
    post(connection['cm_server']).
      payload(query: "{sites {name}}")
  end,
  
  object_definitions: {
       itemFields: {
         fields: lambda do |input, connection, config_fields, object_definitions|
         {
           name: "Test",
           type: "object",
           properties: [
           {
              name: "Value",
              type: "string",
           }
           ]
        }
      end      
       }
  },
   
  actions: {
        update_news_item:{
          description: lambda do |input, picklist_label|
        "NON-GENERIC: Update News Item"
      end,
       input_fields: lambda do
        [
           {
            name: 'language',
            type: 'string',
            optional: false
          },
          {
            name: 'itemId',
            type: 'string',
            optional: false
          },
          {
            name: 'title',
            type: 'string',
            optional: true
          },
          {
            name: 'content',
            type: 'string',
            optional: true
          },
          {
            name: 'abstract',
            type: 'string',
            optional: true
          },
           {
            name: 'tag',
            type: 'string',
            optional: true
          }
        ]
      end,
      execute: lambda do |connection, input|

        newsQuery = 'mutation{
               updateItem(
                 input: { 
                   language:"' + input["language"] + 
                   '" itemId:"'+ input["itemId"] +
                   '" database:"master" 
                   fields: ['
        queryClosing = ']
                 }
               )
               {
                  item{
                    itemId
                  }
                }
              }'
        
        
        
        if input["title"].present? and not input["title"]&.empty?
           titleQuery = '{name:"Title", value: "'+ input["title"] + '"}'
          newsQuery = newsQuery + titleQuery
        end
             
        if input["content"].present? and not input["content"]&.empty?
            contentQuery = '{name:"Content", value: """' + input["content"] + '"""}'
          newsQuery = newsQuery + contentQuery
        end
                   
        if input["abstract"].present? and not input["abstract"]&.empty?
           abstractQuery = '{name:"Abstract", value: "' + input["abstract"] + '"}'
          newsQuery = newsQuery + abstractQuery    
        end
        
         if input["tag"].present? and not input["tag"]&.empty?
           abstractQuery = '{name:"Tag", value: "' + input["tag"] + '"}'
          newsQuery = newsQuery + abstractQuery    
        end
          
        newsQuery = newsQuery + queryClosing
        
        post(connection['cm_server']).
           payload(query: newsQuery)
      
        end,
      
      output_fields: lambda do
        [
           {
            name: "data",
            type: "object",
            properties: [
               {
            name: "item",
            type: "object",
            properties: [
          {
            name: "itemId",
            type: "string"
          }]}]}]
              end
    },
  add_item_version:{
       input_fields: lambda do
        [
           {
            name: 'language',
            type: 'string',
            optional: false
          },
          {
            name: 'itemId',
            type: 'string',
            optional: false
          }
        ]
      end,
      execute: lambda do |connection, input|
          
        post(connection['cm_server']).
           payload(query:
             'mutation{
               addItemVersion(
                 input: { 
                   language:"' + input["language"] + 
                   '" itemId:"'+ input["itemId"] +
                   '" database:"master"
                 }
               )
               {
                  item{
                    itemId
                  }
                }
              }')
      end,
      
      output_fields: lambda do
        [
           {
            name: "data",
            type: "array",
            of: "object",
            properties: [
               {
            name: "item",
            type: "array",
            of: "object",
            properties: [
          {
            name: "itemId",
            type: "string"
          }]}]}]
              end
    },
    get_languages_to_translate:{
       description: lambda do |input, picklist_label|
        "NON-GENERIC: Get Languages to Translate"
       end,
       input_fields: lambda do
        [
           {
            name: 'language',
            label: 'Language',
            type: 'string',
            optional: false
          },
          {
            name: 'tenant',
            label: 'Tenant',
            type: 'string',
            optional: false
          },
          {
            name: 'site',
            label: 'Site',
            type: 'string',
            optional: false
          }
        ]
      end,
      execute: lambda do |connection, input|
          
        post(connection['cm_server']).
           payload(query:'{
           item(
             where: { 
               language:"' + input["language"] + '" 
               path:"/sitecore/content/' +input["tenant"] + '/' + input["site"] + '/settings/Translation" 
               database:"master"})
               { 
                 TargetLanguages: field(name: "Target Languages"){value}}}')
      end,
      
      output_fields: lambda do
        [
           {
            name: "data",
            type: "object",
            properties: [
               {
            name: "item",
            type: "object",
            properties: [
          {
            name: "TargetLanguages",
            type: "object",
            properties: [
              {
                name: "value",
                type: "string"
              }
            ]
          }]}]}]
              end
    },
  get_languageItem_Iso_Code:{
     description: lambda do |input, picklist_label|
        "NON-GENERIC: Get Language Item ISO Code"
       end,
       input_fields: lambda do
        [
           {
            name: 'language',
            label: 'Language',
            type: 'string',
            optional: false
          },
          {
            name: 'itemId',
            label: 'Item ID',
            type: 'string',
            optional: false
          }
        ]
      end,
      execute: lambda do |connection, input|
          
        post(connection['cm_server']).
           payload(query:'{
           item(
             where: { 
               language:"' + input["language"] + '" 
               path:"' + input["itemId"] + '" 
               database:"master"})
               { 
                 IsoCode: field(name: "Regional Iso Code"){value}
                 Iso: field(name: "Iso"){value}
               }
             }')
      end,
      
      output_fields: lambda do
        [
           {
            name: "data",
            type: "object",
            properties: [
               {
            name: "item",
            type: "object",
            properties: [
          {
            name: "IsoCode",
            type: "object",
            properties: [
              {
                name: "value",
                type: "string"
              }
            ]
          },
            {
            name: "Iso",
            type: "object",
            properties: [
              {
                name: "value",
                type: "string"
              }
            ]
          }]}]}]
              end
    },
    get_news_details: {
       description: lambda do |input, picklist_label|
        "NON-GENERIC: Get News Details"
       end,
      input_fields: lambda do
        [
          {
            name: 'language',
            label: 'Language',
            type: 'string',
            optional: false
          },
          {
            name: 'item_id',
            label: 'Item ID',
            type: 'string',
            optional: false
          }
        ]
      end,

      execute: lambda do |connection, input|
       
        post(connection['cm_server']).
           payload(query:'{
           item(
             where: {
             language:"' + input["language"] + '" 
             itemId:"' +input["item_id"] + '" 
             database:"master"}){
               name 
               path 
               url 
               version
               workflow {workflowState{final}}
               template{templateId}  
               Title: field(name: "Title"){value} 
               Content: field(name: "Content"){value}
               Abstract: field(name: "Abstract"){value}
             }
           }')
      end,

      output_fields: lambda do
        [
           {
            name: "data",
            type: "object",
            properties: [
            {
              name: "item",
              type: "object",
              properties: [
              {
                name: "name",
                type: "string"
              }, {
                name: "version",
                type: "integer"
              }, 
                {
                name: "workflow",
                type: "object",
                  properties: [
                    {
                name: "workflowState",
                type: "object",
                      properties: [
                        {
                name: "final",
                type: "boolean"
              }, 
                      ]
              }, 
                  ]
              }, 
              {
                name: "Content",
                type: "object",
                properties: [
                {
                  name: "value",
                  type: "string"
                }
                ]
              },
                {
                name: "Title",
                type: "object",
                properties: [
                {
                  name: "value",
                  type: "string"
                }
                ]
              },
                {
                name: "Abstract",
                type: "object",
                properties: [
                {
                  name: "value",
                  type: "string"
                }
                ]
              }
              ]
             }
            ]
           }     
        ]
      end
    },
   get_item: {
       description: lambda do |input, picklist_label|
        "Get Item"
       end,
      input_fields: lambda do
        [
          {
            name: 'language',
            label: 'Language',
            type: 'string',
            optional: false
          },
          {
            name: 'item_id',
            label: 'Item ID',
            type: 'string',
            optional: false
          }
        ]
      end,

      execute: lambda do |connection, input|
       
        post(connection['cm_server']).
           payload(query:'{
           item(
             where: {
             language:"' + input["language"] + '" 
             itemId:"' +input["item_id"] + '" 
             database:"master"}){
               name 
               path 
               url 
               version
               workflow {workflowState{final}}
               template{templateId}  
               url
             }
           }')
      end,

      output_fields: lambda do
        [
           {
            name: "data",
            type: "object",
            properties: [
            {
              name: "item",
              type: "object",
              properties: [
              {
                name: "name",
                type: "string"
              },
                 {
                name: "path",
                type: "string"
              },
                 {
                name: "url",
                type: "string",
              },{
                name: "version",
                type: "integer"
              }, 
                {
                name: "workflow",
                type: "object",
                  properties: [
                    {
                name: "workflowState",
                type: "object",
                      properties: [
                        {
                name: "final",
                type: "boolean"
              }, 
                      ]
              }, 
                  ]
              }, 
              ]
             }
            ]
           }     
        ]
      end
    },
    update_faq_item:{
       description: lambda do |input, picklist_label|
        "NON-GENERIC: Update FAQ Item"
       end,
       input_fields: lambda do
        [
           {
            name: 'language',
            type: 'string',
            optional: false
          },
          {
            name: 'itemId',
            type: 'string',
            optional: false
          },
          {
            name: 'answer',
            type: 'string',
            optional: false
          }
        ]
      end,
      execute: lambda do |connection, input|
          
        post(connection['cm_server']).
           payload(query:
             'mutation{
               updateItem(
                 input: { 
                   language:"' + input["language"] + 
                   '" itemId:"'+ input["itemId"] +
                   '" database:"master" 
                   fields: [
                     {name:"Answer", value: """' + input["answer"] + '"""}
                   ]
                 }
               )
               {
                  item{
                    itemId
                  }
                }
              }')
      end,
      
      output_fields: lambda do
        [
           {
            name: "data",
            type: "object",
            properties: [
               {
            name: "item",
            type: "object",
            properties: [
          {
            name: "itemId",
            type: "string"
          }]}]}]
              end
    },
   update_comment_item:{
     description: lambda do |input, picklist_label|
        "NON-GENERIC: Update Comment Item"
       end,
       input_fields: lambda do
        [
           {
            name: 'language',
            type: 'string',
            optional: false
          },
          {
            name: 'itemId',
            type: 'string',
            optional: false
          },
          {
            name: 'sexual',
            type: 'string',
            optional: false
          },
           {
            name: 'hate',
            type: 'string',
            optional: false
           },
           {
            name: 'violence',
            type: 'string',
            optional: false
          },
           {
            name: 'self harm',
            type: 'string',
            optional: false
          },
           {
            name: 'sexual minors',
            type: 'string',
            optional: false
          },
           {
            name: 'hate threatening',
            type: 'string',
            optional: false
          },
           {
            name: 'violence graphic',
            type: 'string',
            optional: false
          },          
          {
            name: 'sexual score',
            type: 'string',
            optional: false
          },
           {
            name: 'hate score',
            type: 'string',
            optional: false
           },
           {
            name: 'violence score',
            type: 'string',
            optional: false
          },
           {
            name: 'self harm score',
            type: 'string',
            optional: false
          },
           {
            name: 'sexual minors score',
            type: 'string',
            optional: false
          },
           {
            name: 'hate threatening score',
            type: 'string',
            optional: false
          },
           {
            name: 'violence graphic score',
            type: 'string',
            optional: false
          },
           {
            name: 'flagged',
            type: 'string',
            optional: false
          }
        ]
      end,
      execute: lambda do |connection, input|
          
        post(connection['cm_server']).
           payload(query:
             'mutation{
               updateItem(
                 input: { 
                   language:"' + input["language"] + 
                   '" itemId:"'+ input["itemId"] +
                   '" database:"master" 
                   fields: [
                     {name:"sexual", value: "' + input["sexual"] + '"}
                     {name:"hate", value: "' + input["hate"] + '"}
                     {name:"violence", value: "' + input["violence"] + '"}
                     {name:"self harm", value: "' + input["self harm"] + '"}
                     {name:"sexual minors", value: "' + input["sexual minors"] + '"}
                     {name:"hate threatening", value: "' + input["hate threatening"] + '"}
                     {name:"violence graphic", value: "' + input["violence graphic"] + '"}
                     {name:"sexual score", value: "' + input["sexual score"] + '"}
                     {name:"hate score", value: "' + input["hate score"] + '"}
                     {name:"violence score", value: "' + input["violence score"] + '"}
                     {name:"self harm score", value: "' + input["self harm score"] + '"}
                     {name:"sexual minors score", value: "' + input["sexual minors score"] + '"}
                     {name:"hate threatening score", value: "' + input["hate threatening score"] + '"}
                     {name:"violence graphic score", value: "' + input["violence graphic score"] + '"}
                     {name:"flagged", value: "' + input["flagged"] + '"}
                     ]
                 }
               )
               {
                  item{
                    itemId
                  }
                }
              }')
      end,
      
      output_fields: lambda do
        [
           {
            name: "data",
            type: "object",
            properties: [
               {
            name: "item",
            type: "object",
            properties: [
          {
            name: "itemId",
            type: "string"
          }]}]}]
              end
    },
     execute_workflow_command:{
       input_fields: lambda do
        [
           {
            name: 'language',
            type: 'string',
            optional: false
          },
          {
            name: 'itemId',
            type: 'string',
            optional: false
          },
          {
            name: 'commandId',
            type: 'string',
            optional: false
          }
        ]
      end,
      execute: lambda do |connection, input|
          
        post(connection['cm_server']).
           payload(query:
             'mutation{
               executeWorkflowCommand(
                 input: { 
                   commandId:"' + input["commandId"] + '"
                   item:{
                     language:"' + input["language"] + '" 
                     itemId:"' + input["itemId"] + '" 
                     database:"master" 
                   }
                 }
               )
               {
                  successful
                }
              }')
      end,
      
      output_fields: lambda do
        [
           {
            name: "data",
            type: "object",
            properties: [
               {
            name: "executeWorkflowCommand",
            type: "object",
            properties: [
          {
            name: "successful",
            type: "boolean"
          }]}]}]
              end
    },
  create_comment_item:{
     description: lambda do |input, picklist_label|
        "NON-GENERIC: Create Comment Item"
       end,
       input_fields: lambda do
        [
           {
            name: 'language',
            type: 'string',
            optional: false
          },
          {
            name: 'name',
            type: 'string',
            optional: false
          },
          {
            name: 'title',
            type: 'string',
            optional: false
          },
          {
            name: 'comment',
            type: 'string',
            optional: false
          },
          {
            name: 'username',
            type: 'string',
            optional: false
          },
          {
            name: 'email',
            type: 'string',
            optional: false
          },
            {
            name: 'templateId',
            type: 'string',
            optional: false
          },
            {
            name: 'parent',
            type: 'string',
            optional: false
          }
        ]
      end,
      execute: lambda do |connection, input|
          
   post(connection['cm_server']).
           payload(query:
             'mutation{
               createItem(
                 input: { 
                   language:"' + input["language"] + 
                   '" name:"'+ input["name"] +
                   '" templateId:"'+ input["templateId"] +
                   '" parent:"'+ input["parent"] +
                   '" database:"master" 
                   fields: [
                     {name:"comment", value: "' + input["comment"] + '"}
                     {name:"user", value: "' + input["username"] + '"}
                     {name:"email", value: "' + input["email"] + '"}
                     {name:"title", value: "' + input["title"] + '"}
                     ]
                 }
               )
               {
                  item{
                    itemId
                    path
                  }
                }
              }')
      end,
      
      output_fields: lambda do
        [
           {
            name: "data",
            type: "object",
            properties: [
              {
            name: "createItem", 
            type: "object",
            properties: [
               {
            name: "item",
            type: "object",
            properties: [
          {
            name: "itemId",
            type: "string"
          },
            {
            name: "path",
            type: "string"
          }]}]}]}]
              end
    },
  get_itemId_by_path:{
       input_fields: lambda do
        [
           {
            name: 'path',
            label: 'path',
            type: 'string',
            optional: false
          }
        ]
      end,
      execute: lambda do |connection, input|
          
        post(connection['cm_server']).
           payload(query:'{
           item(
             where: { 
               path:"' +input["path"] + '" 
               database:"master"})
               { 
                 itemId}}')
      end,
      
      output_fields: lambda do
        [
           {
            name: "data",
            type: "object",
            properties: [
               {
            name: "item",
            type: "object",
            properties: [
          {
            name: "itemId",
            type: "string",
          }
            ]}]}]
              end
    },
   get_comments:{
     description: lambda do |input, picklist_label|
        "NON-GENERIC: Get Comments from Comment Module"
       end,
       input_fields: lambda do
        [
           {
            name: 'path',
            label: 'path',
            type: 'string',
            optional: false
          }
        ]
      end,
      execute: lambda do |connection, input|
          
        post(connection['cm_server']).
           payload(query:'{
           item(
             where: { 
               path:"' +input["path"] + '" 
               database:"master"})
               { 
                 itemId
                 comments: field(name:"comments"){value}}}')
      end,
      
      output_fields: lambda do
        [
           {
            name: "data",
            type: "object",
            properties: [
               {
            name: "item",
            type: "object",
            properties: [
          {
            name: "itemId",
            type: "string",
          },
               {
            name: "comments",
            type: "object",
                 properties: [
                   {
            name: "value",
            type: "string",
          } 
                 ]
          }
            ]}]}]
              end
    },
      update_comments_datasource:{
        description: lambda do |input, picklist_label|
        "NON-GENERIC: Update Comment List in Comment Module"
       end,
       input_fields: lambda do
        [
           {
            name: 'language',
            type: 'string',
            optional: false
          },
          {
            name: 'itemId',
            type: 'string',
            optional: false
          },
          {
            name: 'comments',
            type: 'string',
            optional: false
          }
        ]
      end,
      execute: lambda do |connection, input|
          
   post(connection['cm_server']).
           payload(query:
             'mutation{
               updateItem(
                 input: { 
                   language:"' + input["language"] + 
                   '" itemId:"'+ input["itemId"] +
                   '" database:"master" 
                   fields: [
                     {name:"comments", value: "' + input["comments"] + '"}
                 ]}
               )
               {
                  item{
                    itemId
                  }
                }
              }')
      end,
      
      output_fields: lambda do
        [
           {
            name: "data",
            type: "object",
            properties: [
               {
            name: "item",
            type: "object",
            properties: [
          {
            name: "itemid",
            type: "string"
          }]}]}]
              end
},
   search_items:{  
     description: lambda do |input, picklist_label|
        "Search for Items (NOTE: Currently not fully generic implemented - Outputfields are still statically defined)"
      end,
       help: "Currently not 100% generic (Output fields are fixed)",
       input_fields: lambda do
        [
           {
            name: 'language',
            label: 'Language',
            type: 'string',
            optional: false
          },
           {
            name: 'templateId',
            label: 'Template Item ID',
            type: 'string',
            optional: false
          },
          {
            name: 'rootItemId',
            label: 'Root Item ID',
            type: 'string',
            optional: false
          },
       {
          name: "itemFields",
          extends_schema: true,
          schema_neutral: false,
          control_type: 'schema-designer',
          label: 'Item Fields',
          hint: 'Define the fields to be retrieved from Item',
          item_label: 'button',
          add_field_label: 'Custom Add Label',
          empty_schema_message: 'Custom empty schema message that allows to <button type="button" data-action="addField">add field</button> and <button type="button" data-action="generateSchema">generate schema</button>',
          sample_data_type: 'json_input' # json_input / xml / csv
       }     
        ]
      end,
      execute: lambda do |connection, input, object_definitions|
        
        targetQuery = '{
           search(
             query: { 
               index : "sitecore_master_index" 
               language: "' + input["language"] + '"
               searchStatement: {
                 criteria: [
                   {
                    criteriaType: EXACT
                    operator: MUST
                    field: "_template"
                    value: "' +input["templateId"] + '"
                   }
                   {
                    operator: MUST
                    field: "_path"
                    value: "' + input["rootItemId"] + '"
                   }                 
                 ]
                }
             }
           )
           { 
             results{
               itemId
               innerItem{'
        
         workato.parse_json(input["itemFields"]).each{ |n| puts 
          propName = n["name"]
          propFieldName = n["name"];
          if propName == "DisplayName"
            propFieldName = "__Display Name"
          end
          
          targetQuery = targetQuery +  propName + ' : field(name: "'+ propFieldName +'"){
                   value
                  } '
         }
          
        targetQuery= targetQuery + '}
             }
           }
          }'

        post(connection['cm_server']).
           payload(query: targetQuery)            
      end,
      
      output_fields: lambda do |connection, input, object_definitions|
        
        
        [
           {
            name: "data",
            type: "object",
            properties: [
               {
            name: "search",
            type: "object",
            properties: [
          {
            name: "results",
            type: "array",
            properties: [
              {
                name: "itemId",
                type: "string"
              },
              {
                name: "innerItem",
                type: "object",
                properties: [
               {
                  name: "Title",
                  type: "object",
                  properties: [
                 {
                   name: "Value",
                   type: "string",
                  }
               ]
              }
                ]
              }
            ]
          }]}]}]
              end
    },
create_item:{
       input_fields: lambda do
        [
           {
            name: 'language',
            type: 'string',
            optional: false
          },
          {
            name: 'name',
            type: 'string',
            optional: false
          },
            {
            name: 'templateId',
            type: 'string',
            optional: false
          },
            {
            name: 'parent',
            type: 'string',
            optional: false
          },
           {
          name: "itemFields",
          control_type: "key_value",
          label: "Item Fields",
          empty_list_title: "Add fields",
          type: "array",
          of: "object",
          properties: [
            { name: "name"},
            { name: "value"}
           ]
         }  
        ]
      end,
      execute: lambda do |connection, input|
          
        targetQuery = 'mutation{
               createItem(
                 input: { 
                   language:"' + input["language"] + 
                   '" name:"'+ input["name"] +
                   '" templateId:"'+ input["templateId"] +
                   '" parent:"'+ input["parent"] +
                   '" database:"master" 
                   fields: ['
        queryEnd =' ]
                 }
               )
               {
                  item{
                    itemId
                    path
                  }
                }
              }'
        
       if input["itemFields"].present? 
         input["itemFields"].each{ |n| puts 
           fieldName = n["name"]
           fieldValue = n["value"];
          if fieldName == "DisplayName"
            fieldName = "__Display Name"
          end
          
          targetQuery = targetQuery +  '{name:"' +fieldName +'", value: "' + fieldValue + '"}'
         }
       end
        
        targetQuery = targetQuery + queryEnd;
                                    
   post(connection['cm_server']).
           payload(query: targetQuery)
      end,
      
      output_fields: lambda do
        [
           {
            name: "data",
            type: "object",
            properties: [
              {
            name: "createItem", 
            type: "object",
            properties: [
               {
            name: "item",
            type: "object",
            properties: [
          {
            name: "itemId",
            type: "string"
          },
            {
            name: "path",
            type: "string"
          }]}]}]}]
              end
    },
}

  #More connector code here
}